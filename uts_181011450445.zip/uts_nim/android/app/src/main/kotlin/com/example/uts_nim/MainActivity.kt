package com.example.uts_nim

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
